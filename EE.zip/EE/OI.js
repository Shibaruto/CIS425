//page link to  tabcontent to help execute them
function openPage(event, pageName) {
  var i, tant, meneu;
  tant = document.getElementsByClassName("tant");
  for (i = 0; i < tant.length; i++) {
    tant[i].style.display = "none";
  }
  meneu = document.getElementsByClassName("meneu");
  for (i = 0; i < meneu.length; i++) {
    meneu[i].className = meneu[i].className.replace(" active"," ");
  }
  document.getElementById(pageName).style.display = "block";
  event.currentTarget.className += " active";
}

// page dark or light mode persay
function myFunction() {
   var element = document.body;
   element.classList.toggle("dark-mode");
}

function m() {
  var modal = document.getElementById('id01');
  document.getElementById('id01').href = "/EE/sub.html";
}
