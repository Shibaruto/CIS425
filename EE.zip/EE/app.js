const express = require('express');
var bodyParser = require('body-parser')
const app = express();

var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.get('/EE/O.html', (req, res) => {
  res.sendFile(__dirname + '/O.html');
});

app.get('/EE/tes.html', (req, res) => {
  res.sendFile(__dirname + '/tes.html');
});

app.get('/EE/sub.html', (req, res) => {
  res.sendFile(__dirname + '/sub.html');
});

app.get('/EE/OI.js', (req, res) => {
  res.sendFile(__dirname + '/OI.js');
});

app.get('/EE/tes.js', (req, res) => {
  res.sendFile(__dirname + '/tes.js');
});

app.get('/EE/sub.js', (req, res) => {
  res.sendFile(__dirname + '/sub.js');
});

app.post('/', urlencodedParser, (req, res) => {
    console.log('Got body:', req.body);
    res.sendStatus(200);
});

app.listen(3000);
